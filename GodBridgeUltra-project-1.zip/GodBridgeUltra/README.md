# GodBridge Ultra — Minecraft Java 1.8.9 / Forge

Client-side bridging helper with toggle, settings screen, HUD, saved configuration, and configurable placement cooldown. Intended for local testing or servers where such automation is permitted. It does **not** include anti-ban claims or protection bypasses. Server-side placement validation still applies; automatic placement is not guaranteed to work in every situation or server.

## Controls
- **B**: toggle helper (chat status).
- **U**: open settings GUI.
- By default, hold **Sneak** and a movement key to allow placement attempts.
- GUI: toggle, cooldown (1–10 ticks), HUD, and sneak requirement.

## Build
Requires a JDK 8 environment and Gradle 2.14.1 / ForgeGradle 2.1. Run `gradle clean build`. The GitHub Actions workflow installs Java 8 and Gradle 2.14.1 and uploads the resulting JAR if the build succeeds. The wrapper scripts included here are lightweight fallbacks, not the official Gradle wrapper JAR.

## Install on PojavLauncher
1. Install Minecraft **1.8.9** with Forge **11.15.1.2318** in PojavLauncher.
2. Build the project and copy `build/libs/GodBridgeUltra-1.8.9-1.1.0.jar` into `.minecraft/mods/`.
3. Launch the Forge profile. Press **B** to toggle or **U** for settings. On Android, keyboard shortcuts require a connected keyboard or a compatible on-screen key-mapping feature.
4. Test first in a single-player creative world. Back up worlds before testing mods.

## Known limitations / verification
- This code targets legacy Forge/Minecraft 1.8.9 APIs. Actual compilation and in-game behavior must be verified in a Java 8 + ForgeGradle environment.
- Placement uses normal client interaction and server validation; it is not a guaranteed full-direction scaffold implementation.
- Safe Walk is not implemented as a separate collision hook in this version.
- Key codes are loaded from `config/godbridgeultra.cfg` at startup (defaults: B and U). GUI key rebinding is not yet provided; restart the game after editing the file.
- No anti-ban guarantee is possible. Follow each server's rules.
