@echo off
REM Minimal convenience launcher; requires Gradle installed on the system.
gradle %*
