package com.godbridge.ultra;

import net.minecraftforge.common.config.Configuration;
import java.io.File;

/** Persistent client settings. Values are clamped before use. */
public final class ModConfig {
    private static Configuration config;
    public static boolean enabledByDefault = false;
    public static boolean showHud = true;
    public static boolean requireSneak = true;
    public static int placementCooldown = 3;
    public static int toggleKey = 48; // B
    public static int guiKey = 22; // U
    private ModConfig() {}

    public static void load(File file) {
        config = new Configuration(file);
        sync();
    }
    public static void sync() {
        if (config == null) return;
        config.load();
        showHud = config.get("general", "showHud", true, "Show the small status HUD").getBoolean(true);
        requireSneak = config.get("general", "requireSneak", true, "Require sneak to attempt placement").getBoolean(true);
        placementCooldown = clamp(config.get("placement", "cooldownTicks", 3, "Ticks between placement attempts", 1, 10).getInt(3),1,10);
        toggleKey = config.get("keys", "toggleKey", 48, "LWJGL key code for toggle (B=48)").getInt(48);
        guiKey = config.get("keys", "guiKey", 22, "LWJGL key code for settings (U=22)").getInt(22);
        if (config.hasChanged()) config.save();
    }
    public static void save() {
        if (config == null) return;
        config.get("general", "showHud", true).set(showHud);
        config.get("general", "requireSneak", true).set(requireSneak);
        config.get("placement", "cooldownTicks", 3).set(clamp(placementCooldown,1,10));
        config.get("keys", "toggleKey", 48).set(toggleKey);
        config.get("keys", "guiKey", 22).set(guiKey);
        config.save();
    }
    private static int clamp(int v,int min,int max){ return Math.max(min,Math.min(max,v)); }
}
