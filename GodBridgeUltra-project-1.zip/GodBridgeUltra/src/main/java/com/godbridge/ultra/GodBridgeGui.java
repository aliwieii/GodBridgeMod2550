package com.godbridge.ultra;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;

public final class GodBridgeGui extends GuiScreen {
    private static final int TOGGLE=1, CD_DOWN=2, CD_UP=3, HUD=4, SNEAK=5, CLOSE=6;
    @Override public void initGui() {
        buttonList.clear();
        int x=width/2-100, y=height/2-65;
        buttonList.add(new GuiButton(TOGGLE,x,y,200,20,"GodBridge: "+(GodBridgeUltra.isEnabled()?"ON":"OFF")));
        buttonList.add(new GuiButton(CD_DOWN,x,y+25,40,20,"-"));
        buttonList.add(new GuiButton(CD_UP,x+160,y+25,40,20,"+"));
        buttonList.add(new GuiButton(HUD,x,y+50,200,20,"HUD: "+(ModConfig.showHud?"ON":"OFF")));
        buttonList.add(new GuiButton(SNEAK,x,y+75,200,20,"Require sneak: "+(ModConfig.requireSneak?"ON":"OFF")));
        buttonList.add(new GuiButton(CLOSE,x,y+105,200,20,"Save and close"));
    }
    @Override protected void actionPerformed(GuiButton b) throws IOException {
        switch(b.id) {
            case TOGGLE: GodBridgeUltra.setEnabled(!GodBridgeUltra.isEnabled()); break;
            case CD_DOWN: ModConfig.placementCooldown=Math.max(1,ModConfig.placementCooldown-1); break;
            case CD_UP: ModConfig.placementCooldown=Math.min(10,ModConfig.placementCooldown+1); break;
            case HUD: ModConfig.showHud=!ModConfig.showHud; break;
            case SNEAK: ModConfig.requireSneak=!ModConfig.requireSneak; break;
            case CLOSE: ModConfig.save(); mc.displayGuiScreen(null); return;
        }
        initGui();
    }
    @Override public void drawScreen(int mx,int my,float partial) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj,"GodBridge Ultra — Settings",width/2,height/2-88,0x55FFFF);
        drawCenteredString(fontRendererObj,"Attempt cooldown: "+ModConfig.placementCooldown+" ticks",width/2,height/2-33,0xFFFFFF);
        super.drawScreen(mx,my,partial);
    }
    @Override public boolean doesGuiPauseGame(){return false;}
}
