package com.godbridge.ultra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public final class GodBridgeHud extends Gui {
    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.TEXT || !ModConfig.showHud) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;
        FontRenderer f = mc.fontRendererObj;
        String state = GodBridgeUltra.isEnabled() ? EnumChatFormatting.GREEN + "ON" : EnumChatFormatting.RED + "OFF";
        String line = EnumChatFormatting.AQUA + "GodBridge " + state + EnumChatFormatting.GRAY + " | CD " + ModConfig.placementCooldown + "t";
        drawRect(4, 4, 8 + f.getStringWidth(line), 18, 0x90000000);
        f.drawStringWithShadow(line, 6, 7, 0xFFFFFF);
    }
}
