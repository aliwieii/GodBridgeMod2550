package com.godbridge.ultra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Mod(modid=GodBridgeUltra.MODID,name=GodBridgeUltra.NAME,version=GodBridgeUltra.VERSION,clientSideOnly=true,acceptedMinecraftVersions="[1.8.9]")
public class GodBridgeUltra {
    public static final String MODID="godbridgeultra", NAME="GodBridge Ultra", VERSION="1.1.0";
    private static final Minecraft MC=Minecraft.getMinecraft();
    private static boolean enabled=false;
    private static KeyBinding toggleKey, guiKey;
    private int cooldown=0;
    private BlockPos lastAttempt=null;

    public static boolean isEnabled(){return enabled;}
    public static void setEnabled(boolean value){enabled=value;}
    @Mod.EventHandler public void preInit(FMLPreInitializationEvent e){ModConfig.load(new java.io.File(e.getModConfigurationDirectory(),"godbridgeultra.cfg"));}
    @Mod.EventHandler public void init(FMLInitializationEvent e){
        toggleKey=new KeyBinding("key.godbridgeultra.toggle",ModConfig.toggleKey,"key.categories.godbridgeultra");
        guiKey=new KeyBinding("key.godbridgeultra.gui",ModConfig.guiKey,"key.categories.godbridgeultra");
        ClientRegistry.registerKeyBinding(toggleKey); ClientRegistry.registerKeyBinding(guiKey);
        MinecraftForge.EVENT_BUS.register(this); MinecraftForge.EVENT_BUS.register(new GodBridgeHud());
    }
    @SubscribeEvent public void onTick(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END) return;
        if(MC.thePlayer==null || MC.theWorld==null) return;
        while(toggleKey.isPressed()){enabled=!enabled; message("GodBridge "+(enabled?"§aON":"§cOFF"));}
        while(guiKey.isPressed()){if(MC.currentScreen==null) MC.displayGuiScreen(new GodBridgeGui());}
        if(cooldown>0) cooldown--;
        if(!enabled || cooldown>0 || MC.currentScreen!=null || MC.thePlayer.isSpectator() || MC.thePlayer.capabilities.isFlying) return;
        if(ModConfig.requireSneak && !MC.gameSettings.keyBindSneak.isKeyDown()) return;
        if(!MC.gameSettings.keyBindForward.isKeyDown() && !MC.gameSettings.keyBindBack.isKeyDown() && !MC.gameSettings.keyBindLeft.isKeyDown() && !MC.gameSettings.keyBindRight.isKeyDown()) return;
        ItemStack stack=MC.thePlayer.getHeldItem();
        if(stack==null || stack.stackSize<=0 || !(stack.getItem() instanceof ItemBlock)){lastAttempt=null;return;}
        BlockPos target=new BlockPos(MC.thePlayer.posX, MC.thePlayer.getEntityBoundingBox().minY-0.01D, MC.thePlayer.posZ);
        if(!MC.theWorld.isAirBlock(target) || target.equals(lastAttempt)) return;
        // Find a real neighboring face. No fabricated reach or anti-detection behavior.
        EnumFacing[] faces={EnumFacing.NORTH,EnumFacing.SOUTH,EnumFacing.WEST,EnumFacing.EAST,EnumFacing.DOWN};
        for(EnumFacing side:faces){
            BlockPos anchor=target.offset(side);
            if(MC.theWorld.isAirBlock(anchor)) continue;
            EnumFacing face=side.getOpposite();
            Vec3 hit=new Vec3(anchor.getX()+0.5D,anchor.getY()+0.5D,anchor.getZ()+0.5D);
            double reach=MC.thePlayer.getPositionEyes(1.0F).squareDistanceTo(hit);
            if(reach>MC.playerController.getBlockReachDistance()*MC.playerController.getBlockReachDistance()) continue;
            boolean placed=MC.playerController.onPlayerRightClick(MC.thePlayer,MC.theWorld,stack,anchor,face,hit);
            if(placed){lastAttempt=target; MC.thePlayer.swingItem(); cooldown=ModConfig.placementCooldown;}
            else { cooldown=1; }
            return;
        }
    }
    private static void message(String s){if(MC.thePlayer!=null) MC.thePlayer.addChatMessage(new ChatComponentText("§3[GodBridge Ultra] §f"+s));}
}
